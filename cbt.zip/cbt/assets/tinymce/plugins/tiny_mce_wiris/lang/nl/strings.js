var strings = new Array();
strings['cancel'] = 'Annuleren';
strings['accept'] = 'OK';
strings['manual'] = 'Handleiding';
strings['latex'] = 'LaTeX';