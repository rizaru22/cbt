var strings = new Array();
strings['cancel'] = 'Cancel';
strings['accept'] = 'OK';
strings['manual'] = 'Manual';
strings['latex'] = 'LaTeX';