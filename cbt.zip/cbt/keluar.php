<div class="col-md-4 col-md-offset-4">

<div class="panel panel-default panel-keluar">
   <div class="panel-heading">
      <h3><b>Konfirmasi Test</b></h3>
   </div>
   <div class="panel-body">
				  
		Terimakasih telah berpartisipasi dalam tes ini.<br>
		Silahkan klik tombol LOGOUT untuk mengakhiri test.
		
   </div>
   <div class="panel-footer">
		<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<a href="logout.php" class="btn btn-success btn-block">LOGOUT</a>
		</div>		
		</div>
   </div>
</div>

 </div>